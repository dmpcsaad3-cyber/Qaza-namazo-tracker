# Qaza Namaz Tracker (قضائے عمری ٹریکر) - Flutter App

A complete, production-ready Flutter application for tracking Qaza-e-Umri (missed prayers).

## Features
- **6 Prayers Support**: Fajr, Dhuhr, Asr, Maghrib, Isha, and Witr Wajib.
- **Smart Qaza Calculator**: Calculates total days and prayers based on missed years, months, and days.
- **Daily Target**: Set and track daily completion goals with progress bar.
- **Local Persistence**: Full offline support using `shared_preferences`.
- **History Logs**: Real-time activity logs tracking every prayer offered or added.
- **Islamic Guidance**: Detailed Qaza rules, Niyyah, and forbidden prayer times.

## How to Run
1. Ensure Flutter SDK is installed.
2. Run `flutter pub get`.
3. Run `flutter run`.
