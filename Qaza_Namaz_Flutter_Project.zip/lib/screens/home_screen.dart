import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/prayer_provider.dart';
import '../widgets/prayer_card.dart';
import '../widgets/summary_card.dart';
import '../widgets/dialogs.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void _showCalculatorDialog() {
    int years = 1;
    int months = 0;
    int days = 0;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) {
          final totalDays = (years * 365) + (months * 30) + days;
          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.calculate, color: Color(0xFF004D40)),
                SizedBox(width: 8),
                Text('قضا کیلکولیٹر', style: TextStyle(fontSize: 18)),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'اپنی چھوٹی ہوئی مدت (سال، مہینے، دن) درج کریں:',
                    style: TextStyle(fontSize: 13, color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  _buildSlider(
                    label: 'سال (Years): $years',
                    val: years.toDouble(),
                    max: 60,
                    onChanged: (v) => setDialogState(() => years = v.round()),
                  ),
                  _buildSlider(
                    label: 'مہینے (Months): $months',
                    val: months.toDouble(),
                    max: 11,
                    onChanged: (v) => setDialogState(() => months = v.round()),
                  ),
                  _buildSlider(
                    label: 'دن (Days): $days',
                    val: days.toDouble(),
                    max: 29,
                    onChanged: (v) => setDialogState(() => days = v.round()),
                  ),
                  const Divider(),
                  Center(
                    child: Column(
                      children: [
                        const Text('کل قضا ایام:', style: TextStyle(fontSize: 14)),
                        Text(
                          '$totalDays دن',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF004D40),
                          ),
                        ),
                        Text(
                          'ہر نماز کی تعداد: $totalDays رکھی جائے گی',
                          style: const TextStyle(fontSize: 11, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('منسوخ'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF004D40)),
                onPressed: () {
                  context.read<PrayerProvider>().setCalculatedDays(totalDays);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('تمام نمازیں $totalDays پر سیٹ کر دی گئیں!')),
                  );
                },
                child: const Text('لاگو کریں'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSlider({
    required String label,
    required double val,
    required double max,
    required ValueChanged<double> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        Slider(
          value: val,
          min: 0,
          max: max,
          divisions: max.toInt(),
          activeColor: const Color(0xFF004D40),
          onChanged: onChanged,
        ),
      ],
    );
  }

  void _showEditPrayerDialog(String id, String name, int currentCount) {
    final controller = TextEditingController(text: currentCount.toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$name کی تعداد تبدیل کریں'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'نئی تعداد درج کریں',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('منسوخ'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF004D40)),
            onPressed: () {
              final val = int.tryParse(controller.text) ?? currentCount;
              context.read<PrayerProvider>().setPrayerCount(id, val);
              Navigator.pop(context);
            },
            child: const Text('محفوظ کریں'),
          ),
        ],
      ),
    );
  }

  void _showDailyTargetDialog() {
    final current = context.read<PrayerProvider>().dailyTarget;
    final controller = TextEditingController(text: current.toString());

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('روزانہ کا ہدف (Daily Target)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('آپ روزانہ کتنی قضا نمازیں ادا کرنے کا ارادہ رکھتے ہیں؟'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'ہدف (نمازوں کی تعداد)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('منسوخ'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF004D40)),
            onPressed: () {
              final val = int.tryParse(controller.text) ?? current;
              context.read<PrayerProvider>().setDailyTarget(val);
              Navigator.pop(context);
            },
            child: const Text('محفوظ کریں'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PrayerProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'قضائے عمری ٹریکر',
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
        ),
        backgroundColor: const Color(0xFF004D40),
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.calculate_outlined),
            tooltip: 'کیلکولیٹر',
            onPressed: _showCalculatorDialog,
          ),
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'ہسٹری',
            onPressed: () => showDialog(context: context, builder: (_) => const HistoryDialog()),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'target') {
                _showDailyTargetDialog();
              } else if (value == 'guidance') {
                showDialog(context: context, builder: (_) => const GuidanceDialog());
              } else if (value == 'reset') {
                _showResetDialog();
              }
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(
                value: 'target\,
                child: Row(
                  children: [
                    Icon(Icons.flag, size: 20, color: Color(0xFF004D40)),
                    SizedBox(width: 10),
                    Text('روزانہ کا ہدف'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'guidance\,
                child: Row(
                  children: [
                    Icon(Icons.menu_book, size: 20, color: Color(0xFF004D40)),
                    SizedBox(width: 10),
                    Text('مسائل و احکام'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'reset\,
                child: Row(
                  children: [
                    Icon(Icons.refresh, size: 20, color: Colors.red),
                    SizedBox(width: 10),
                    Text('ری سیٹ کریں', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => provider.loadData(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  const SummaryCard(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'نمازوں کی تفصیل',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF004D40),
                          ),
                        ),
                        Text(
                          'کل 6 نمازیں (بشمول وتر)',
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  ),
                  ...provider.prayers.map((prayer) => PrayerCard(
                        prayer: prayer,
                        onDecrement: () => provider.decrementPrayer(prayer.id),
                        onIncrement: () => provider.incrementPrayer(prayer.id),
                        onEdit: () => _showEditPrayerDialog(prayer.id, prayer.nameUr, prayer.count),
                      )),
                  const SizedBox(height: 24),
                ],
              ),
            ),
    );
  }

  void _showResetDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('کیا آپ تمام ڈیٹا ری سیٹ کرنا چاہتے ہیں؟'),
        content: const Text('اس عمل سے تمام نمازوں کا ریکارڈ اور تاریخ صفر ہو جائے گی۔'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('نہیں')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              context.read<PrayerProvider>().resetAll();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تمام ڈیٹا ری سیٹ کر دیا گیا ہے۔')),
              );
            },
            child: const Text('ہاں، ری سیٹ کریں'),
          ),
        ],
      ),
    );
  }
}
