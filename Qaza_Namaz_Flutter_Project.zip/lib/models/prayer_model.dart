import 'dart:convert';

class PrayerModel {
  final String id;
  final String nameEn;
  final String nameUr;
  final int rakats;
  int count;

  PrayerModel({
    required this.id,
    required this.nameEn,
    required this.nameUr,
    required this.rakats,
    this.count = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id\: id,
      'nameEn\: nameEn,
      'nameUr\: nameUr,
      'rakats\: rakats,
      'count\: count,
    };
  }

  factory PrayerModel.fromMap(Map<String, dynamic> map) {
    return PrayerModel(
      id: map['id'],
      nameEn: map['nameEn'],
      nameUr: map['nameUr'],
      rakats: map['rakats'] ?? 0,
      count: map['count'] ?? 0,
    );
  }
}

class HistoryEntry {
  final String prayerName;
  final int amountChanged;
  final DateTime timestamp;
  final bool isAddition;

  HistoryEntry({
    required this.prayerName,
    required this.amountChanged,
    required this.timestamp,
    required this.isAddition,
  });

  Map<String, dynamic> toMap() {
    return {
      'prayerName\: prayerName,
      'amountChanged\: amountChanged,
      'timestamp\: timestamp.toIso8601String(),
      'isAddition\: isAddition,
    };
  }

  factory HistoryEntry.fromMap(Map<String, dynamic> map) {
    return HistoryEntry(
      prayerName: map['prayerName'],
      amountChanged: map['amountChanged'],
      timestamp: DateTime.parse(map['timestamp']),
      isAddition: map['isAddition'] ?? false,
    );
  }
}
