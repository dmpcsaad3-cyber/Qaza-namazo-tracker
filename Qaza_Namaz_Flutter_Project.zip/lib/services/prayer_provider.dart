import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/prayer_model.dart';

class PrayerProvider extends ChangeNotifier {
  static const String _prayersKey = 'qaza_prayers_data_v1';
  static const String _historyKey = 'qaza_history_data_v1';
  static const String _targetKey = 'qaza_daily_target_v1';

  List<PrayerModel> _prayers = [
    PrayerModel(id: 'fajr\, nameEn: 'Fajr', nameUr: 'فجر', rakats: 2, count: 0),
    PrayerModel(id: 'dhuhr\, nameEn: 'Dhuhr', nameUr: 'ظہر', rakats: 4, count: 0),
    PrayerModel(id: 'asr\, nameEn: 'Asr', nameUr: 'عصر', rakats: 4, count: 0),
    PrayerModel(id: 'maghrib\, nameEn: 'Maghrib', nameUr: 'مغرب', rakats: 3, count: 0),
    PrayerModel(id: 'isha\, nameEn: 'Isha', nameUr: 'عشاء', rakats: 4, count: 0),
    PrayerModel(id: 'witr\, nameEn: 'Witr', nameUr: 'وتر', rakats: 3, count: 0),
  ];

  List<HistoryEntry> _history = [];
  int _dailyTarget = 5;
  int _todayOffered = 0;
  bool _isLoading = true;

  List<PrayerModel> get prayers => _prayers;
  List<HistoryEntry> get history => _history;
  int get dailyTarget => _dailyTarget;
  int get todayOffered => _todayOffered;
  bool get isLoading => _isLoading;

  int get totalRemainingPrayers => _prayers.fold(0, (sum, p) => sum + p.count);

  PrayerProvider() {
    loadData();
  }

  Future<void> loadData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      _dailyTarget = prefs.getInt(_targetKey) ?? 5;

      final prayersJson = prefs.getString(_prayersKey);
      if (prayersJson != null) {
        final List decoded = jsonDecode(prayersJson);
        _prayers = decoded.map((e) => PrayerModel.fromMap(e)).toList();
      }

      final historyJson = prefs.getString(_historyKey);
      if (historyJson != null) {
        final List decoded = jsonDecode(historyJson);
        _history = decoded.map((e) => HistoryEntry.fromMap(e)).toList();
      }

      _calculateTodayOffered();
    } catch (e) {
      debugPrint('Error loading data: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  void _calculateTodayOffered() {
    final now = DateTime.now();
    _todayOffered = _history.where((entry) {
      return !entry.isAddition &&
          entry.timestamp.year == now.year &&
          entry.timestamp.month == now.month &&
          entry.timestamp.day == now.day;
    }).fold(0, (sum, entry) => sum + entry.amountChanged);
  }

  Future<void> decrementPrayer(String id, {int amount = 1}) async {
    final index = _prayers.indexWhere((p) => p.id == id);
    if (index != -1 && _prayers[index].count > 0) {
      final actualReduction = _prayers[index].count >= amount ? amount : _prayers[index].count;
      _prayers[index].count -= actualReduction;

      _history.insert(0, HistoryEntry(
        prayerName: '${_prayers[index].nameUr} (${_prayers[index].nameEn})',
        amountChanged: actualReduction,
        timestamp: DateTime.now(),
        isAddition: false,
      ));

      _todayOffered += actualReduction;
      await _saveData();
      notifyListeners();
    }
  }

  Future<void> incrementPrayer(String id, {int amount = 1}) async {
    final index = _prayers.indexWhere((p) => p.id == id);
    if (index != -1) {
      _prayers[index].count += amount;

      _history.insert(0, HistoryEntry(
        prayerName: '${_prayers[index].nameUr} (${_prayers[index].nameEn})',
        amountChanged: amount,
        timestamp: DateTime.now(),
        isAddition: true,
      ));

      await _saveData();
      notifyListeners();
    }
  }

  Future<void> setPrayerCount(String id, int newCount) async {
    final index = _prayers.indexWhere((p) => p.id == id);
    if (index != -1) {
      _prayers[index].count = newCount < 0 ? 0 : newCount;
      await _saveData();
      notifyListeners();
    }
  }

  Future<void> setDailyTarget(int target) async {
    _dailyTarget = target;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_targetKey, _dailyTarget);
    notifyListeners();
  }

  Future<void> setCalculatedDays(int totalDays) async {
    for (var p in _prayers) {
      p.count = totalDays;
    }
    _history.insert(0, HistoryEntry(
      prayerName: 'تمام نمازیں (Calculator Auto-fill)',
      amountChanged: totalDays,
      timestamp: DateTime.now(),
      isAddition: true,
    ));
    await _saveData();
    notifyListeners();
  }

  Future<void> resetAll() async {
    for (var p in _prayers) {
      p.count = 0;
    }
    _history.clear();
    _todayOffered = 0;
    await _saveData();
    notifyListeners();
  }

  Future<void> _saveData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final prayersJson = jsonEncode(_prayers.map((e) => e.toMap()).toList());
      await prefs.setString(_prayersKey, prayersJson);

      final historyJson = jsonEncode(_history.map((e) => e.toMap()).toList());
      await prefs.setString(_historyKey, historyJson);
    } catch (e) {
      debugPrint('Error saving data: $e');
    }
  }
}
