import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/prayer_model.dart';

class PrayerCard extends StatelessWidget {
  final PrayerModel prayer;
  final VoidCallback onDecrement;
  final VoidCallback onIncrement;
  final VoidCallback onEdit;

  const PrayerCard({
    Key? key,
    required this.prayer,
    required this.onDecrement,
    required this.onIncrement,
    required this.onEdit,
  }) : super(key: key);

  Color _getPrayerColor(String id) {
    switch (id) {
      case 'fajr\:
        return const Color(0xFF00796B);
      case 'dhuhr\:
        return const Color(0xFFF57C00);
      case 'asr\:
        return const Color(0xFFE65100);
      case 'maghrib\:
        return const Color(0xFF7B1FA2);
      case 'isha\:
        return const Color(0xFF1565C0);
      case 'witr\:
        return const Color(0xFF2E7D32);
      default:
        return const Color(0xFF004D40);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = _getPrayerColor(prayer.id);
    final isDone = prayer.count == 0;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDone ? Colors.green.withOpacity(0.3) : themeColor.withOpacity(0.15),
            width: 1.5,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: themeColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.mosque,
                color: themeColor,
                size: 26,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        prayer.nameUr,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '(${prayer.nameEn})',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${prayer.rakats} رکعت فرض',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: onEdit,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Column(
                  children: [
                    Text(
                      NumberFormat.decimalPattern().format(prayer.count),
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: isDone ? Colors.green : Colors.redAccent.shade700,
                      ),
                    ),
                    Text(
                      isDone ? 'مکمل': 'باقی',
                      style: TextStyle(
                        fontSize: 10,
                        color: isDone ? Colors.green : Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: onIncrement,
                  icon: const Icon(Icons.add_circle_outline),
                  color: Colors.blueGrey,
                  tooltip: 'قضا بڑھائیں',
                ),
                FilledButton.tonal(
                  onPressed: prayer.count > 0 ? onDecrement : null,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF004D40),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check, size: 16),
                      SizedBox(width: 4),
                      Text('ادا', style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
