import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/prayer_provider.dart';

class HistoryDialog extends StatelessWidget {
  const HistoryDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final history = context.watch<PrayerProvider>().history;

    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.history, color: Color(0xFF004D40)),
          SizedBox(width: 8),
          Text('تاریخچہ (History Logs)', style: TextStyle(fontSize: 18)),
        ],
      ),
      content: SizedBox(
        width: double.maxFinite,
        height: 400,
        child: history.isEmpty
            ? const Center(
                child: Text(
                  'ابھی تک کوئی ریکارڈ موجود نہیں ہے۔',
                  style: TextStyle(color: Colors.grey),
                ),
              )
            : ListView.separated(
                itemCount: history.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final item = history[index];
                  final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: item.isAddition
                          ? Colors.orange.withOpacity(0.15)
                          : Colors.green.withOpacity(0.15),
                      child: Icon(
                        item.isAddition ? Icons.add : Icons.check,
                        color: item.isAddition ? Colors.orange : Colors.green,
                        size: 18,
                      ),
                    ),
                    title: Text(item.prayerName, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(
                      dateFormat.format(item.timestamp),
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                    trailing: Text(
                      '${item.isAddition ? "+" : "-"}${item.amountChanged}',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: item.isAddition ? Colors.orange.shade800 : Colors.green.shade800,
                      ),
                    ),
                  );
                },
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('بند کریں'),
        ),
      ],
    );
  }
}

class GuidanceDialog extends StatelessWidget {
  const GuidanceDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.menu_book, color: Color(0xFF004D40)),
          SizedBox(width: 8),
          Text('قضا نماز کے اہم مسائل', style: TextStyle(fontSize: 18)),
        ],
      ),
      content: const SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '1. قضائے عمری کیا ہے؟',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF004D40)),
            ),
            SizedBox(height: 4),
            Text(
              'بلوغت کی عمر کے بعد جو نمازیں کسی غفلت یا مجبوری کی وجہ سے رہ گئی ہوں، ان کی قضا ادا کرنا فرض ہے۔',
              style: TextStyle(fontSize: 13),
            ),
            SizedBox(height: 12),
            Text(
              '2. وتر کی نماز واجب ہے:',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF004D40)),
            ),
            SizedBox(height: 4),
            Text(
              'احناف کے نزدیک روزانہ کی 5 نمازوں کے ساتھ عشاء کی 3 رکعت وتر واجب بھی قضا میں شامل ہے۔ لہٰذا روزانہ کی 20 رکعتیں بنتی ہیں۔',
              style: TextStyle(fontSize: 13),
            ),
            SizedBox(height: 12),
            Text(
              '3. نیت کا آسان طریقہ:',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF004D40)),
            ),
            SizedBox(height: 4),
            Text(
              'مثلاً: "نیت کرتا ہوں میں پہلی قضا فجر کی جو مجھ پر باقی ہے"۔ دل کا ارادہ ہی کافی ہے۔',
              style: TextStyle(fontSize: 13),
            ),
            SizedBox(height: 12),
            Text(
              '4. ممنوعہ اوقات:',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF004D40)),
            ),
            SizedBox(height: 4),
            Text(
              'طلوعِ آفتاب، عین زوال (دوپہر 12 بجے کے قریب) اور غروبِ آفتاب کے وقت کوئی بھی قضا نماز نہیں پڑھی جا سکتی۔ باقی تمام اوقات میں پڑھی جا سکتی ہے۔',
              style: TextStyle(fontSize: 13),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('ماشاءاللہ'),
        ),
      ],
    );
  }
}
